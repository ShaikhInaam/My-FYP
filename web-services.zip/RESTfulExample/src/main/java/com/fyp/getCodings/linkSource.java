package com.fyp.getCodings;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

public class linkSource {

	String inputLine=null;
	private StringBuffer buffer=new StringBuffer();
	
	public linkSource(String link) throws Exception
	{
		URL url=new URL(link);
		BufferedReader in=new BufferedReader(new InputStreamReader(url.openStream()));
		StringBuffer response=new StringBuffer();
		
		while((inputLine=in.readLine())!=null)
		{
			response.append(inputLine+"\n");
	
		}
		in.close();
		
		
		buffer=response;
	}
	
	public StringBuffer getSource()
	{
		return buffer;
	}
	
}
