package com.fyp.fieldNames;

import java.util.ArrayList;

public class FieldNames {
	
	
		public ArrayList<String> getFieldNames(StringBuffer source, String url)
		{
			ArrayList<String> names = new ArrayList<String>();
			
			String code = source.toString();
			
			String data[] = code.split("\n");
			
			for(int i = 0; i < data.length; i++)
			{
				if(data[i].contains("<input") && !(data[i].contains("hidden") && !(data[i].contains("submit"))))
				{
					data[i] = data[i].trim();
					if(data[i].contains("name=") || data[i].contains("name ="))
					{						
						if(data[i].contains("name="))
						{
							String ab[] = data[i].split("name=");
							System.out.println(ab[0]);
							String ac[] = ab[1].split("\"");
							names.add(ac[1]);
						}
						else if(data[i].contains("name ="))
						{
							String ab[] = data[i].split("name =");
							System.out.println(ab[0]);
						
							String ac[] = ab[1].split("\"");
							names.add(ac[1]);
						}
					}
				}
			}
			
			
			return names;
		}
		

}
