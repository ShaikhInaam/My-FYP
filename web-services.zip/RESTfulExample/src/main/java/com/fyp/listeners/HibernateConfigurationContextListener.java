package com.fyp.listeners;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import javax.xml.stream.events.StartDocument;



import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;


@WebListener
public class HibernateConfigurationContextListener implements ServletContextListener {


	
	public static Capabilities caps=null;
	public static WebDriver driver;
	public static ArrayList list=new ArrayList();
	
	
    public void contextDestroyed(ServletContextEvent arg0)  { 
         
    }

	
    public void contextInitialized(ServletContextEvent arg0)  { 
         
    	new Thread()
    	{
    		public void run()
    		{
    			Connection con=null;
    			try
    			{
    				Class.forName("com.mysql.jdbc.Driver");
    				con=DriverManager.getConnection("jdbc:mysql://localhost/finalyearproject","root",null);
    				PreparedStatement stmt=con.prepareStatement("Select api_key from com_api");
    				ResultSet set=stmt.executeQuery();
    				
    				set.beforeFirst();
    				if(set.next())
    				{
    					set.first();
    					
    					do
    					{
    						list.add(set.getString("api_key"));
    					}while(set.next());
    				}
    				
    				stmt=con.prepareStatement("Select api_key from api");
    				set=stmt.executeQuery();
    				
    				set.beforeFirst();
    				if(set.next())
    				{
    					set.first();
    					
    					do
    					{
    						list.add(set.getString("api_key"));
    					}while(set.next());
    				}
    				
    				System.out.println("API keys have been stored");
    				
    			}
    			catch(Exception ex)
    			{
    				ex.printStackTrace();
    			}
    			finally
    			{
    				try {
						con.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    			}
    			
    		}
    	}.start();
    
		
		caps = new DesiredCapabilities();
	     ((DesiredCapabilities) caps).setJavascriptEnabled(true);                  
	     ((DesiredCapabilities) caps).setCapability(
	             PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY,
	             "E:/phantomjs-2.1.1-windows/bin/phantomjs.exe" );
	    
	     	 driver=new PhantomJSDriver(caps);
			     
	  		 
    	
	     
    }
	
}
