package com.mkyong.rest;
 
import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
 
@Path("/service")
public class HelloWorldService {
 
	ArrayList keys=com.fyp.listeners.HibernateConfigurationContextListener.list;
	Gson g=new Gson();
	
	@GET
	@Path("/{param}")
	public Response getMsg(@PathParam("param") String msg)throws Exception {
 
		String st[]=msg.split(",");
		String APIkey=st[0];
		String URL=st[1];
		String attack=st[2];
		String keyStatus="Invalid API Key";
		
		ArrayList list1=new ArrayList();
		
		URL=URL.replaceAll("2020", "/");
		APIkey=APIkey.replaceAll("2020", "/");
		
		list1.add("Link : "+URL); 
		list1.add("API key : "+APIkey);
		  
		  
		  for(int i=0;i<keys.size();i++)
		  {
			  if(keys.get(i).toString().equals(APIkey)){
				  keyStatus="Valid API Key";
				  break;
			  }
		  }
		  
		list1.add("Key status : "+keyStatus);
		  
	if(keyStatus.equals("Valid API Key"))
	{
		  
				
		
		StringBuffer buff=new com.fyp.getCodings.linkSource(URL).getSource();
		ArrayList<String> list=new com.fyp.fieldNames.FieldNames().getFieldNames(buff, URL);
		
		if(attack.equals("sql"))
		{
			list1.add("Attack : SQL Injection");
			String source=new com.fyp.executeattacks.Attacks().getByName(list, URL, "abc'or'1'='1");
			StringBuffer buff2 = new StringBuffer(source);
			ArrayList<String> list2 = new com.fyp.fieldNames.FieldNames().getFieldNames(buff2, "");
			
			
			int a=list.size();
			int b=list2.size();
			if(a!=b)
			{
				
				list1.add("Result : Link is vulnerable");
			}
			
			else
			{
				list1.add("Result : Link is safe");
			}
			
			
		}
		
		else if(attack.equals("xss") || attack.equals("session"))
		{
			
			if(attack.equals("xss"))
				list1.add("Attack : Cross Site Scripting");
			
			else
				list1.add("Attack : Session HijackingS");
			
			
			String source=new com.fyp.executeattacks.Attacks().getByName(list, URL, "<scipt>alert('hello');</script>");
			
			StringBuffer buff2 = new StringBuffer(source);
			ArrayList<String> list2 = new com.fyp.fieldNames.FieldNames().getFieldNames(buff2, "");
			
			int count = 0;
			
			for(int i = 0; i < list.size(); i++)
			{
				if(list2.contains(list.get(i)))
				{
					count++;
				}
			}
			
			if(count > 0  && !(source.contains("<scipt>alert('hello');</script>")))
			{
				list1.add("Result : Link is safe");
			}
			else if (source.contains("<scipt>alert('hello');</script>") && count > 0)
			{
				list1.add("Result : Link is vulnerable");
			}
			else if(source.contains("<scipt>alert('hello');</script>"))
			{
				list1.add("Result : Link is vulnerable");
			}
		}
		
		
		
	}	
		
		
		return Response.status(200).entity(g.toJson(list1)).build();
 
	}
 
}