package com.fyp.company_registration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.fyp.beans.Company_Registration_Api_Beans;
import com.fyp.beans.Company_Registration_Beans;
import com.fyp.crypto.EncryptionDecryption;

public class BackEndController extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		
		
		String fname=request.getParameter("first_name");
		String cnic=request.getParameter("cnic_");
		String qualification=request.getParameter("qualification");
		String p_service=request.getParameter("purpose");
		String email=request.getParameter("email_address");
		String mobile_number=request.getParameter("m_number");
		String address=request.getParameter("address_");
		String hacking=request.getParameter("hacking_");
		String password=request.getParameter("password_");
		String p_company=request.getParameter("p_company");
		String c_address=request.getParameter("c_address");
		String c_contact=request.getParameter("c_contact");
		
		
		
		fname=EncryptionDecryption.encrypt(fname);
		qualification=EncryptionDecryption.encrypt(qualification);
		p_service=EncryptionDecryption.encrypt(p_service);
		email=EncryptionDecryption.encrypt(email);
		address=EncryptionDecryption.encrypt(address);
		hacking=EncryptionDecryption.encrypt(hacking);
		password=EncryptionDecryption.encrypt(password);
		p_company=EncryptionDecryption.encrypt(p_company);
		c_address=EncryptionDecryption.encrypt(c_address);
		c_contact=EncryptionDecryption.encrypt(c_contact);
		
		Company_Registration_Beans bean=new Company_Registration_Beans();
		
		bean.setFirst_name(fname);
		bean.setCnic(cnic);
		bean.setQualification(qualification);
		bean.setPurpose(p_service);
		bean.setEmail_address(email);
		bean.setM_number(mobile_number);
		bean.setAddress(address);
		bean.setHacking(hacking);
		bean.setPassword(password);
		bean.setP_company(p_company);
		bean.setC_address(c_address);
		bean.setC_contact(c_contact);
		
		
		Company_Registration_Api_Beans bean2=new Company_Registration_Api_Beans();
		bean2.setApi(email);
		
		//Configuration cfg = new Configuration();
		//cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = com.fyp.listeners.HibernateConfigurationContextListener.sf; 
				//cfg.buildSessionFactory();
		
		
		Session s = sf.openSession();
		s.save(bean);
		s.beginTransaction().commit();
		s.evict(bean);
		s.close();
		s = sf.openSession();
		s.save(bean2);
		s.beginTransaction().commit();
		s.evict(bean2);
		
		
		
		
		
		return mapping.findForward("success");
	}

	
	
	
	
}
