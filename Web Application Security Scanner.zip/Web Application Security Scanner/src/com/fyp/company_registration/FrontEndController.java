package com.fyp.company_registration;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import com.fyp.regula_expressions.Validator;

public class FrontEndController extends ActionForm{

	private String first_name,qualification,purpose,email_address,m_number,address_,hacking_,cnic_,p_company,
	c_address,c_contact,solve_captcha_,password_,r_password_;


	
	//------------FORM BACKUP-------------------------------------------------------------
	
	public String getFirst_name() {
		return first_name;
	}



	public String getQualification() {
		return qualification;
	}



	public String getPurpose() {
		return purpose;
	}



	public String getEmail_address() {
		return email_address;
	}



	public String getM_number() {
		return m_number;
	}



	public String getAddress_() {
		return address_;
	}



	public String getHacking_() {
		return hacking_;
	}



	public String getCnic_() {
		return cnic_;
	}



	public String getP_company() {
		return p_company;
	}



	public String getC_address() {
		return c_address;
	}



	public String getC_contact() {
		return c_contact;
	}



	public String getSolve_captcha_() {
		return solve_captcha_;
	}



	public String getPassword_() {
		return password_;
	}



	public String getR_password_() {
		return r_password_;
	}



	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}



	public void setQualification(String qualification) {
		this.qualification = qualification;
	}



	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}



	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}



	public void setM_number(String m_number) {
		this.m_number = m_number;
	}



	public void setAddress_(String address_) {
		this.address_ = address_;
	}



	public void setHacking_(String hacking_) {
		this.hacking_ = hacking_;
	}



	public void setCnic_(String cnic_) {
		this.cnic_ = cnic_;
	}



	public void setP_company(String p_company) {
		this.p_company = p_company;
	}



	public void setC_address(String c_address) {
		this.c_address = c_address;
	}



	public void setC_contact(String c_contact) {
		this.c_contact = c_contact;
	}



	public void setSolve_captcha_(String solve_captcha_) {
		this.solve_captcha_ = solve_captcha_;
	}



	public void setPassword_(String password_) {
		this.password_ = password_;
	}



	public void setR_password_(String r_password_) {
		this.r_password_ = r_password_;
	}
	

	
	//
	//----------------------------------------------------------------------------
	//-------------------FORM VALIDATIONS---------------------------------------
	
	
	@Override
	public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {

		ActionErrors ae=new ActionErrors();
		
		boolean bx=Validator.validate(first_name,"[a-zA-Z]");
		boolean bx1=Validator.validate(cnic_, "[0-9]");
		boolean bx2=Validator.validate(qualification, "[^!@#$%^&*()_+|}{'\"]");
		boolean bx3=Validator.validate(purpose, "[a-zA-Z]");
		boolean bx4=Validator.validate(email_address, "[a-zA-Z0-9@.]");
		boolean bx5=Validator.validate(m_number, "[0-9]");
		boolean bx6=Validator.validate(address_, "[a-zA-Z0-9#]");
		boolean bx7=Validator.validate(p_company, "[a-zA-Z]");
		boolean bx8=Validator.validate(c_address, "[a-zA-Z0-9#]");
		boolean bx9=Validator.validate(c_contact, "[0-9]");
		
		
		if(bx==false)
			ae.add(first_name, new ActionMessage("firstname"));
		
		else if(bx2==false)
			ae.add(qualification, new ActionMessage("qualifications"));
		
		else if(bx3==false)
			ae.add(purpose, new ActionMessage("p_service"));
		
		else if(bx4==false)
			ae.add(email_address, new ActionMessage("email"));
		
		else if(bx5==false)
			ae.add(m_number, new ActionMessage("mobile_number"));
		
		else if(bx6==false)
			ae.add(address_, new ActionMessage("address"));
		
		else if(bx1==false)
			ae.add(cnic_, new ActionMessage("cnic"));
		
		else if(bx7==false)
			ae.add(p_company, new ActionMessage("p_company"));
		
		else if(bx8==false)
			ae.add(c_address, new ActionMessage("c_address"));
		
		else if(bx9==false)
			ae.add(c_contact, new ActionMessage("c_contact"));
		
		
		
		
		
		else if(!password_.equals(r_password_) || password_.equals("") || password_.equals(null) || password_.equals(" "))
			ae.add(password_, new ActionMessage("password"));
		
		
		
		
	
		
		
		
		
		
		return ae;
	}



		
	
	
	
	
	
	
}
