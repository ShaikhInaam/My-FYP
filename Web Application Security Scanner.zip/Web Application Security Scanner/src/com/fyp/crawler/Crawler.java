package com.fyp.crawler;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fyp.dos.Attacker;
import com.fyp.executeattacks.Attacks;




@WebServlet("/Crawler")
public class Crawler extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	static StringBuffer sql=new StringBuffer();
	
	public static String URL=null;
	public static boolean bx=true;
	public static String firstname=null;
	public static String secondname=null;
	public static String get1[]=null;
	
	
	
	
	
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
String get=request.getParameter("text_scanner");
		
		
		
		try{
		
		if(!get.startsWith("http") && !get.startsWith("https"))
		{
			String get1="http://"+get;
			URL=get1;
		}
		
		else
			URL=get;
		
		
		
		if(URL.contains("www"))
		{
			get1=URL.split("\\.");
			firstname=get1[1];
			secondname=firstname+"."+get1[2];
		}
		
		else
		{
			get1=URL.split(":");
			String get2[]=get1[1].split("\\.");
			String get3=get2[0].substring(2);
			firstname=get3;
			secondname=get3+"."+get2[1];
		}
		
		
		
		
		
		
		}catch(Exception ex)
		{
			
			PrintWriter out=response.getWriter();
			 	out.println("<script type=\"text/javascript\">");
			   out.println("alert('invalid input address');");
			   out.println("alert('"+ex.getMessage()+"');");
			   out.println("location='index.jsp';");
			   out.println("</script>");
			   out.close();
			bx=false;
			
		}
			
		
		
		
		
		
		
			
		try {
			
			
			
			if(bx==true){
				
				
				String data = com.fyp.listeners.HibernateConfigurationContextListener.data;
				
				String attack = request.getParameter("attack");
				
				boolean isVulnerable = false;
				
				StringBuffer buff=new com.fyp.getCodings.linkSource(URL).getSource();
				ArrayList<String> list=new com.fyp.fieldNames.FieldNames().getFieldNames(buff, URL);
				
				if(attack.equals("Buffer Overflow"))
				{
					
					
					String source=new com.fyp.executeattacks.Attacks().getByName(list, URL, data);
					System.out.println(data);
					StringBuffer buff2 = new StringBuffer(source);
					ArrayList<String> list2 = new com.fyp.fieldNames.FieldNames().getFieldNames(buff2, "");
					
					int count = 0;
					
					for(int i = 0; i < list.size(); i++)
					{
						if(list2.contains(list.get(i)))
						{
							count++;
						}
					}
					
					if(count > 0)
					{
						System.out.println("false");
					}
					else
					{
						System.out.println("true");
						isVulnerable = true;
					}
					
					
					request.setAttribute("link", URL);
					request.setAttribute("attack", "Buffer Overflow");
					request.setAttribute("fields", list);
					request.setAttribute("result", isVulnerable);
					
					RequestDispatcher rd = request.getRequestDispatcher("AttackInfo");
					rd.forward(request, response);
					
				}
				
				
				else if(attack.equals("Denial of Service"))
				{
					
					new Thread()
					{
						
						Attacker att=new Attacker(URL);
						
					}.start();
					
					response.sendRedirect("index.jsp");
					
					
				}
				
				else if(attack.equals("Session Hijacking"))
				{
					String source=new com.fyp.executeattacks.Attacks().getByName(list, URL, "<scipt>alert('hello');</script>");
					
					StringBuffer buff2 = new StringBuffer(source);
					ArrayList<String> list2 = new com.fyp.fieldNames.FieldNames().getFieldNames(buff2, "");
					
					int count = 0;
					
					for(int i = 0; i < list.size(); i++)
					{
						if(list2.contains(list.get(i)))
						{
							count++;
						}
					}
					
					if(count > 0  && !(source.contains("<scipt>alert('hello');</script>")))
					{
						System.out.println("false");
					}
					else if (source.contains("<scipt>alert('hello');</script>") && count > 0)
					{
						System.out.println("true");
						isVulnerable = true;
					}
					else if(source.contains("<scipt>alert('hello');</script>"))
					{
						System.out.println("true");
						isVulnerable = true;
					}
					
					
					request.setAttribute("link", URL);
					request.setAttribute("attack", "Session Hijacking");
					request.setAttribute("fields", list);
					request.setAttribute("result", isVulnerable);
					
					RequestDispatcher rd = request.getRequestDispatcher("AttackInfo");
					rd.forward(request, response);
					
				}
				
				else if(attack.equals("Cross Site Scripting"))
				{
					String source=new com.fyp.executeattacks.Attacks().getByName(list, URL, "<scipt>alert('hello');</script>");
					
					StringBuffer buff2 = new StringBuffer(source);
					ArrayList<String> list2 = new com.fyp.fieldNames.FieldNames().getFieldNames(buff2, "");
					
					int count = 0;
					
					for(int i = 0; i < list.size(); i++)
					{
						if(list2.contains(list.get(i)))
						{
							count++;
						}
					}
					
					if(count > 0  && !(source.contains("<scipt>alert('hello');</script>")))
					{
						System.out.println("false");
					}
					else if (source.contains("<scipt>alert('hello');</script>") && count > 0)
					{
						System.out.println("true");
						isVulnerable = true;
					}
					else if(source.contains("<scipt>alert('hello');</script>"))
					{
						System.out.println("true");
						isVulnerable = true;
					}
					
					
					request.setAttribute("link", URL);
					request.setAttribute("attack", "Cross Site Scripting");
					request.setAttribute("fields", list);
					request.setAttribute("result", isVulnerable);
					
					RequestDispatcher rd = request.getRequestDispatcher("AttackInfo");
					rd.forward(request, response);
					
				}
				
				else if(attack.equals("Structured Query Language Injection"))
				{
					String source=new com.fyp.executeattacks.Attacks().getByName(list, URL, "abc'or'1'='1");
					
					StringBuffer buff2 = new StringBuffer(source);
					ArrayList<String> list2 = new com.fyp.fieldNames.FieldNames().getFieldNames(buff2, "");
					
					
					int a=list.size();
					int b=list2.size();
					if(a!=b)
					{
						System.out.println("true");
						isVulnerable = true;
					}
					
					else
					{
						System.out.println("false");
					}
					
					
					request.setAttribute("link", URL);
					request.setAttribute("attack", "Structured Query Language Injection");
					request.setAttribute("fields", list);
					request.setAttribute("result", isVulnerable);
					
					RequestDispatcher rd = request.getRequestDispatcher("AttackInfo");
					rd.forward(request, response);
				}
				
				
				
				
					
				
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
					e.printStackTrace();
					PrintWriter out=response.getWriter();
					 out.println("<script type=\"text/javascript\">");
					   out.println("alert('No Internet or slow connection problem');");
					  // out.println("alert('"+e.getMessage()+"');");
					   out.println("location='index.jsp';");
					   out.println("</script>");
					   out.close();
		}
		
		}
		
		
	
	
	
	
	
	} // end of main class Crawler




