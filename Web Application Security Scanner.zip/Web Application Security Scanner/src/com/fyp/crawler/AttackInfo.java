package com.fyp.crawler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.fyp.beans.Attack_Info_Beans;


@WebServlet("/AttackInfo")
public class AttackInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String attack = request.getAttribute("attack").toString();
		String URL = request.getAttribute("link").toString();
		ArrayList<String> list = (ArrayList<String>) request.getAttribute("fields");
		boolean isVulnerable = (boolean) request.getAttribute("result");
		
		
		SessionFactory sf=com.fyp.listeners.HibernateConfigurationContextListener.sf;
		
		String java ="";
		String python ="";
		String php ="";
		String dotnet ="";
		String result="Your Website is secured!";
		
		
		Attack_Info_Beans bean; 
		Session s; 
		Transaction tx; 
		Query q; 
		List l;
		
		switch(attack)
		{
			
			
			
			case "Structured Query Language Injection":
		
				bean = new Attack_Info_Beans();
				
				s = sf.openSession();
				tx = s.beginTransaction();
				q = s.createQuery("from com.fyp.beans.Attack_Info_Beans attack where attack.id=:id");
			
				q = q.setParameter("id", 1);
				l = q.list();
				
				
				for (Iterator iterator = l.iterator(); iterator.hasNext();)
				{
					Attack_Info_Beans beans = (Attack_Info_Beans) iterator.next();
				     java = beans.getJava(); 
				     python = beans.getPython();
				     php = beans.getPhp();
				     dotnet = beans.getDotnet();
				}
				tx.commit();
				
				s.close();
				
				request.setAttribute("attack", "Structured Query Language Injection");
				
				if(isVulnerable == true)
				{
					result= "Your Website is Vulnerable to Structured Query Language Injection!";
				}
			
				
				
				
				
			break;
			
			case "Cross Site Scripting":
				
				bean = new Attack_Info_Beans();
				
				s = sf.openSession();
				tx = s.beginTransaction();
				q = s.createQuery("from com.fyp.beans.Attack_Info_Beans attack where attack.id=:id");
			
				q = q.setParameter("id", 2);
				l = q.list();
				
				
				for (Iterator iterator = l.iterator(); iterator.hasNext();)
				{
				     Attack_Info_Beans beans = (Attack_Info_Beans) iterator.next();  
				     java = beans.getJava(); 
				     python = beans.getPython();
				     php = beans.getPhp();
				     dotnet = beans.getDotnet();
				}
				tx.commit();
				
				s.close();
				
				request.setAttribute("attack", "Cross Site Scripting");
				
				if(isVulnerable == true)
				{
					result= "Your Website is Vulnerable to Cross Site Scripting!";
				}

				
				
				
				
				
			break;
			
			
			case "Buffer Overflow":
				
				
				bean = new Attack_Info_Beans();
				
				s = sf.openSession();
				tx = s.beginTransaction();
				q = s.createQuery("from com.fyp.beans.Attack_Info_Beans attack where attack.id=:id");
			
				q = q.setParameter("id", 3);
				l = q.list();
				
				
				for (Iterator iterator = l.iterator(); iterator.hasNext();)
				{
				     Attack_Info_Beans beans = (Attack_Info_Beans) iterator.next(); 
				     java = beans.getJava(); 
				     python = beans.getPython();
				     php = beans.getPhp();
				     dotnet = beans.getDotnet();
				}
				tx.commit();
				
				s.close();
				
				request.setAttribute("attack", "Buffer Overflow");
				
				if(isVulnerable == true)
				{
					result= "Your Website is Vulnerable to Buffer Overflow!";
				}
				
		
				
				
			break;	
			
			
		
		}
		
		
		
		
		
		request.setAttribute("link", URL);
		
		request.setAttribute("fields", list);
		
		request.setAttribute("java", java);
		request.setAttribute("python", python);
		request.setAttribute("php", php);
		request.setAttribute("dotnet", dotnet);
		request.setAttribute("result", result);
		
		RequestDispatcher rd = request.getRequestDispatcher("section.jsp");
		rd.forward(request, response);
		
	}

}
