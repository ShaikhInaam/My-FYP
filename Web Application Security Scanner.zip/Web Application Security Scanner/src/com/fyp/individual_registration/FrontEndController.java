package com.fyp.individual_registration;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import com.fyp.beans.Individual_Registration_Beans;
import com.fyp.regula_expressions.Validator;

public class FrontEndController extends ActionForm{

	
	private String fname,cnic,qualifications,p_service,email,mobile_number,address,hacking,
	password,r_password,study_type,study_value,solve_captcha;


	// FORM BACKUP --------------------------------------------------------------------------------------------------------------------
	
	public String getFname() {
		return fname;
	}


	public String getCnic() {
		return cnic;
	}


	public String getQualifications() {
		return qualifications;
	}


	public String getP_service() {
		return p_service;
	}


	public String getEmail() {
		return email;
	}


	public String getMobile_number() {
		return mobile_number;
	}


	public String getAddress() {
		return address;
	}


	public String getHacking() {
		return hacking;
	}


	public String getPassword() {
		return password;
	}


	public String getR_password() {
		return r_password;
	}


	public String getStudy_type() {
		return study_type;
	}


	public String getStudy_value() {
		return study_value;
	}


	public String getSolve_captcha() {
		return solve_captcha;
	}


	public void setFname(String fname) {
		this.fname = fname;
	}


	public void setCnic(String cnic) {
		this.cnic = cnic;
	}


	public void setQualifications(String qualifications) {
		this.qualifications = qualifications;
	}


	public void setP_service(String p_service) {
		this.p_service = p_service;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public void setMobile_number(String mobile_number) {
		this.mobile_number = mobile_number;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public void setHacking(String hacking) {
		this.hacking = hacking;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public void setR_password(String r_password) {
		this.r_password = r_password;
	}


	public void setStudy_type(String study_type) {
		this.study_type = study_type;
	}


	public void setStudy_value(String study_value) {
		this.study_value = study_value;
	}


	public void setSolve_captcha(String solve_captcha) {
		this.solve_captcha = solve_captcha;
	}



	
	
	// FORM VALIDATIONS -----------------------------------------------------------------------------------------------------------
	
	
	
	
	
	
	
	@Override
	public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {
		
		
		ActionErrors ae=new ActionErrors();
		
		boolean bx=Validator.validate(fname,"[a-zA-Z]");
		boolean bx1=Validator.validate(cnic, "[0-9]");
		boolean bx2=Validator.validate(qualifications, "[^!@#$%^&*()_+|}{'\"]");
		boolean bx3=Validator.validate(p_service, "[a-zA-Z]");
		boolean bx4=Validator.validate(email, "[a-zA-Z0-9@.]");
		boolean bx5=Validator.validate(mobile_number, "[0-9]");
		boolean bx6=Validator.validate(address, "[a-zA-Z0-9#]");
		
		
		
		if(bx==false)
			ae.add(fname, new ActionMessage("firstname"));
		
		else if(bx1==false)
			ae.add(cnic, new ActionMessage("cnic"));
		
		else if(bx2==false)
			ae.add(qualifications, new ActionMessage("qualifications"));
		
		else if(bx3==false)
			ae.add(p_service, new ActionMessage("p_service"));
		
		else if(bx4==false)
			ae.add(email, new ActionMessage("email"));
		
		else if(bx5==false)
			ae.add(mobile_number, new ActionMessage("mobile_number"));
		
		else if(bx6==false)
			ae.add(address, new ActionMessage("address"));
		
		else if(!password.equals(r_password) || password.equals("") || password.equals(null) || password.equals(" "))
			ae.add(password, new ActionMessage("password"));
		
		else if(study_value.equals("") || study_value.equals(" ") || study_value.equals(null))
			ae.add(study_value, new ActionMessage("study_value"));
		
				
		
		
		return ae;
	}


	
}
