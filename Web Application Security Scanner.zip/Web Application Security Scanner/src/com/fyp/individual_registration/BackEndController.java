package com.fyp.individual_registration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.fyp.beans.Individual_Registration_Api_Beans;
import com.fyp.beans.Individual_Registration_Beans;
import com.fyp.crypto.EncryptionDecryption;

public class BackEndController extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		//System.out.println("Hibernate Starting");
		
		String fname=request.getParameter("fname");
		String cnic=request.getParameter("cnic");
		String qualification=request.getParameter("qualifications");
		String p_service=request.getParameter("p_service");
		String email=request.getParameter("email");
		String mobile_number=request.getParameter("mobile_number");
		String address=request.getParameter("address");
		String hacking=request.getParameter("hacking");
		String password=request.getParameter("password");
		String study_type=request.getParameter("study_type");
		String study_value=request.getParameter("study_value");
		
		
		
		
		fname=EncryptionDecryption.encrypt(fname);
		qualification=EncryptionDecryption.encrypt(qualification);
		p_service=EncryptionDecryption.encrypt(p_service);
		email=EncryptionDecryption.encrypt(email);
		address=EncryptionDecryption.encrypt(address);
		hacking=EncryptionDecryption.encrypt(hacking);
		password=EncryptionDecryption.encrypt(password);
		study_type=EncryptionDecryption.encrypt(study_type);
		study_value=EncryptionDecryption.encrypt(study_value);
		
		Individual_Registration_Beans bean=new Individual_Registration_Beans();
		bean.setFirstname(fname);
		bean.setCnic(cnic);
		bean.setQualification(qualification);
		bean.setPurpose(p_service);
		bean.setEmail(email);
		bean.setMobile(mobile_number);
		bean.setAddress(address);
		bean.setHackingexperience(hacking);
		bean.setPassword(password);
		bean.setStudyValue(study_type+"::"+study_value);
		
		Individual_Registration_Api_Beans bean2=new Individual_Registration_Api_Beans();
		bean2.setApi(email);
		
		//Configuration cfg = new Configuration();
		//cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = com.fyp.listeners.HibernateConfigurationContextListener.sf;
				//cfg.buildSessionFactory();
		Session s = sf.openSession();
		s.save(bean);
		
		s.beginTransaction().commit();
		
		s.evict(bean);
		s.close();
		s = sf.openSession();
		s.save(bean2);
		s.beginTransaction().commit();
		s.evict(bean2);
		
		
		return mapping.findForward("success");
	}

	
	
}
