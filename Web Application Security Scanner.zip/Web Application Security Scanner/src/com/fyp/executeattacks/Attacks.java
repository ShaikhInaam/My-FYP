package com.fyp.executeattacks;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Attacks {
	
	private static ArrayList<String> list=new ArrayList<String>();
	private static String link;
	private static String query;
	static WebDriver driver;
	public static Capabilities caps=null;
			
	
	public static String getByName(ArrayList<String> list, String link, String query)
	{
		Attacks.list=list;
		Attacks.link=link;
		Attacks.query=query;
		
		String source=work();
		
		
		return source;
	}
	
	public static String getById(ArrayList<String> list, String link, String query)
	{
		Attacks.list=list;
		Attacks.link=link;
		Attacks.query=query;
		
		
		
		return null;
	}
	
	public static String work()
	{
		
		
		
	
		 
		 driver=com.fyp.listeners.HibernateConfigurationContextListener.driver;
		
		
	     
	     
	    
		
		 driver.get(Attacks.link);
		 
		 int size=Attacks.list.size();
		 
		 
		 
		WebElement element[]=new WebElement[30];
		
		for(int j=0;j<size;j++)
		{
			element[j]=driver.findElement(By.name(Attacks.list.get(j)));
			element[j].sendKeys(Attacks.query);
		}
		
		
		element[size-1].submit(); 
		
		String source=driver.getPageSource();
		
		 
		 
		

		
		return source;
	}
	
}
