package com.fyp.regula_expressions;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator {
	
	
	private static Pattern p=null;
	private static Matcher m=null;
	
	public static boolean validate(String name,String pattern)
	{
		int count=0;
		boolean bx=true;
		
		if(name=="" || name==null)
		
			bx=false;
		
		
		else
		{
			p=Pattern.compile(pattern);
			m=p.matcher(name);
			
			while(m.find())
			{
				count++;
			}
			
			if(count==name.length())
				bx= true;
			
			else
				bx= false;
			
			
		}
		
		
		
		return bx;
	}
	
	
	
	

}
