package com.fyp.listeners;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import javax.xml.stream.events.StartDocument;


import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;


@WebListener
public class HibernateConfigurationContextListener implements ServletContextListener {


	public static SessionFactory sf=null;
	public static Capabilities caps=null;
	public static WebDriver driver;
	public static String data="aa";
	
    public void contextDestroyed(ServletContextEvent arg0)  { 
         
    }

	
    public void contextInitialized(ServletContextEvent arg0)  { 
         
    	Configuration cfg = new Configuration();
		
		
		
		new Thread()
	    {
	    	public void run()
	    	{
	    		cfg.configure("hibernate.cfg.xml");
	    		sf = cfg.buildSessionFactory();
	    		
	    		System.out.println("hibernate initialised");
	    		
	    	}
	    }.start();
		
		
		caps = new DesiredCapabilities();
	     ((DesiredCapabilities) caps).setJavascriptEnabled(true);                  
	     ((DesiredCapabilities) caps).setCapability(
	             PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY,
	             "E:/phantomjs-2.1.1-windows/bin/phantomjs.exe" );
	    
	     	 driver=new PhantomJSDriver(caps);
			     
			     System.out.println("phanttom JS initialised");
	     
	   
	    		 for(int i = 0; i <= 400; i++)
		 			{
		 				data = data.concat("aaaaaaaaaaaaaaaaaaaaaaaa");
		 			}
		 	     
		 	     System.out.println("data ariable initialized");
		 
	  
	    		 
    	
	     
    }
	
}
