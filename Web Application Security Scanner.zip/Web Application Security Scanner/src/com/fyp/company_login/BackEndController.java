package com.fyp.company_login;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.fyp.beans.Company_Login_Beans;
import com.fyp.crypto.EncryptionDecryption;

public class BackEndController extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		
		String result="success";
		
		String email=request.getParameter("email");
		String cnic=request.getParameter("cnic");
		String password=request.getParameter("password");
		
		email=EncryptionDecryption.encrypt(email);
		password=EncryptionDecryption.encrypt(password);
		
		Company_Login_Beans bean=new Company_Login_Beans();
		
		bean.setCnic(cnic);
		bean.setEmail(email);
		bean.setPassword(password);
		
		
		
		SessionFactory sf = com.fyp.listeners.HibernateConfigurationContextListener.sf; 
				
		
		Session s = sf.openSession();
		Query q = s.createQuery("select com.id from com.fyp.beans.Company_Login_Beans com where com.email=:email and com.cnic=:cnic and com.password=:password");
		q = q.setParameter("email", email);
		q = q.setParameter("cnic", cnic);
		q = q.setParameter("password", password);
		List l = q.list();
		
		
		if(l.size()==0)
		{
			result="failuare";
			
		}
		
		return mapping.findForward(result);
	}

	
	
	
	
	
	
	
}
