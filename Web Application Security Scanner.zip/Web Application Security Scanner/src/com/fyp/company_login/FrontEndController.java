package com.fyp.company_login;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import com.fyp.regula_expressions.Validator;

public class FrontEndController extends ActionForm{

	private String email,cnic,p_company,solve_captcha,password;

	
	//--------FORM BACKUP------------------------------------------------------------------------------------------
	
	
	public String getEmail() {
		return email;
	}

	public String getCnic() {
		return cnic;
	}

	public String getP_company() {
		return p_company;
	}

	public String getSolve_captcha() {
		return solve_captcha;
	}

	public String getPassword() {
		return password;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setCnic(String cnic) {
		this.cnic = cnic;
	}

	public void setP_company(String p_company) {
		this.p_company = p_company;
	}

	public void setSolve_captcha(String solve_captcha) {
		this.solve_captcha = solve_captcha;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
	
	//-------FORM VALIDATIONS------------------------------------------------------------------------------------------------
	
	
	@Override
	public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {
		// TODO Auto-generated method stub
		
		ActionErrors ae=new ActionErrors();
		
		
		
		boolean bx1=Validator.validate(cnic, "[0-9]");
		boolean bx2=Validator.validate(email, "[a-zA-Z0-9@.]");
		boolean bx3=Validator.validate(p_company, "[a-zA-Z]");
		
		
		if(bx1==false)
			ae.add(cnic, new ActionMessage("cnic"));
		
		else if(bx2==false)
			ae.add(email, new ActionMessage("email"));
		
		else if(bx3==false)
			ae.add(p_company, new ActionMessage("p_company"));
		
		else if(password.equals("") || password.equals(null) || password.equals(" "))
			ae.add(password, new ActionMessage("pass"));
		
		
		
		return ae;
	}
	
	
	
	
	
	
	
	
}
