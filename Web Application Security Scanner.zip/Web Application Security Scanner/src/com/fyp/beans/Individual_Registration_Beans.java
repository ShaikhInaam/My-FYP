package com.fyp.beans;



public class Individual_Registration_Beans {

	private String firstname,qualification,purpose,email,address,hackingexperience,password,studyValue;
	private String cnic,mobile;
	private int id;
	
	public String getFirstname() {
		return firstname;
	}
	public String getQualification() {
		return qualification;
	}
	public String getPurpose() {
		return purpose;
	}
	public String getEmail() {
		return email;
	}
	public String getMobile() {
		return mobile;
	}
	public String getAddress() {
		return address;
	}
	public String getHackingexperience() {
		return hackingexperience;
	}
	public String getPassword() {
		return password;
	}
	public String getStudyValue() {
		return studyValue;
	}
	public String getCnic() {
		return cnic;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setHackingexperience(String hackingexperience) {
		this.hackingexperience = hackingexperience;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setStudyValue(String studyValue) {
		this.studyValue = studyValue;
	}
	public void setCnic(String cnic) {
		this.cnic = cnic;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	
	
	
	
}
