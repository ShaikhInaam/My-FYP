package com.fyp.beans;

public class Company_Registration_Beans {
	
	private String first_name,qualification,purpose,email_address,m_number,address,hacking,cnic,p_company,
	c_address,c_contact,password;
	private int id;

	public String getFirst_name() {
		return first_name;
	}

	public String getQualification() {
		return qualification;
	}

	public String getPurpose() {
		return purpose;
	}

	public String getEmail_address() {
		return email_address;
	}

	public String getM_number() {
		return m_number;
	}

	public String getAddress() {
		return address;
	}

	public String getHacking() {
		return hacking;
	}

	public String getCnic() {
		return cnic;
	}

	public String getP_company() {
		return p_company;
	}

	public String getC_address() {
		return c_address;
	}

	public String getC_contact() {
		return c_contact;
	}

	public String getPassword() {
		return password;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}

	public void setM_number(String m_number) {
		this.m_number = m_number;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setHacking(String hacking) {
		this.hacking = hacking;
	}

	public void setCnic(String cnic) {
		this.cnic = cnic;
	}

	public void setP_company(String p_company) {
		this.p_company = p_company;
	}

	public void setC_address(String c_address) {
		this.c_address = c_address;
	}

	public void setC_contact(String c_contact) {
		this.c_contact = c_contact;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
	

}
