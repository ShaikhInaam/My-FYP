package com.fyp.beans;

public class Attack_Info_Beans {
	
	private String name, java, php, python, dotnet;
	private int id;

	public Attack_Info_Beans(){}
	public Attack_Info_Beans(String name, String java, String php, String python, String dotnet)
	{
		this.name = name;
		this.java = java;
		this.php = php;
		this.python = python;
		this.dotnet = dotnet;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJava() {
		return java;
	}

	public void setJava(String java) {
		this.java = java;
	}

	public String getPhp() {
		return php;
	}

	public void setPhp(String php) {
		this.php = php;
	}

	public String getPython() {
		return python;
	}

	public void setPython(String python) {
		this.python = python;
	}

	public String getDotnet() {
		return dotnet;
	}

	public void setDotnet(String dotnet) {
		this.dotnet = dotnet;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
