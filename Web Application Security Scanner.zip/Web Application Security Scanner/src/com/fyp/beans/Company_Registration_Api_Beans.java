package com.fyp.beans;

public class Company_Registration_Api_Beans {

	private int id;
	private String api;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getApi() {
		return api;
	}
	public void setApi(String api) {
		this.api = api;
	}

	
}
