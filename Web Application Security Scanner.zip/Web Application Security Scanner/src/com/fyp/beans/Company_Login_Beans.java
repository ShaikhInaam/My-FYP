package com.fyp.beans;

public class Company_Login_Beans {

	private String email,cnic,password;
	private int id;

	public String getEmail() {
		return email;
	}

	public String getCnic() {
		return cnic;
	}

	public String getPassword() {
		return password;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setCnic(String cnic) {
		this.cnic = cnic;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
	
}
