package com.fyp.beans;

public class Individual_Login_Beans {

	private String email_address,nic,m_number,pass;
	private int id;

	public String getEmail_address() {
		return email_address;
	}

	public String getNic() {
		return nic;
	}

	public String getM_number() {
		return m_number;
	}

	public String getPass() {
		return pass;
	}

	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}

	public void setNic(String nic) {
		this.nic = nic;
	}

	public void setM_number(String m_number) {
		this.m_number = m_number;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
	
}
