package com.fyp.individual_login;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.fyp.beans.Individual_Login_Beans;
import com.fyp.beans.Individual_Registration_Beans;
import com.fyp.crypto.EncryptionDecryption;

public class BackEndController extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		
		String result="success";
		
		String email=request.getParameter("email_address");
		String nic=request.getParameter("nic");
		String number=request.getParameter("m_number");
		String pass=request.getParameter("pass");
		
		
		pass=EncryptionDecryption.encrypt(pass);
		email=EncryptionDecryption.encrypt(email);
		
		Individual_Login_Beans bean=new Individual_Login_Beans();
		bean.setEmail_address(email);
		bean.setM_number(number);
		bean.setNic(nic);
		bean.setPass(pass);
		
		
		SessionFactory sf = com.fyp.listeners.HibernateConfigurationContextListener.sf; 
		
		
		Session s = sf.openSession();
		Query q = s.createQuery("select ind.id from com.fyp.beans.Individual_Login_Beans ind where ind.email_address=:email and ind.m_number=:mobile and ind.nic=:cnic and ind.pass=:password");
		q = q.setParameter("email", email);
		q = q.setParameter("cnic", nic);
		q = q.setParameter("mobile", number);
		q = q.setParameter("password", pass);
		List l = q.list();
		
		if(l.size()==0)
		{
			result="failuare";
			
		}
		
		return mapping.findForward(result);
	}

	
	
	
	
}
