package com.fyp.individual_login;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import com.fyp.regula_expressions.Validator;

public class FrontEndController extends ActionForm{

	
	private String email_address,nic,m_number,captcha,pass;

	//--------------FORM BACKUP----------------------------------------------------------------------------------------
	
	public String getEmail_address() {
		return email_address;
	}

	public String getNic() {
		return nic;
	}

	public String getM_number() {
		return m_number;
	}

	public String getCaptcha() {
		return captcha;
	}

	public String getPass() {
		return pass;
	}

	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}

	public void setNic(String nic) {
		this.nic = nic;
	}

	public void setM_number(String m_number) {
		this.m_number = m_number;
	}

	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}
	
	
	//--------FORM VALIDATIONS---------------------------------------------------------------------------------------------------

	@Override
	public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {
		// TODO Auto-generated method stub
		
		ActionErrors ae=new ActionErrors();
		
		
		
		boolean bx1=Validator.validate(nic, "[0-9]");
		boolean bx2=Validator.validate(email_address, "[a-zA-Z0-9@.]");
		boolean bx3=Validator.validate(m_number, "[0-9]");
		
		
		if(bx1==false)
			ae.add(nic, new ActionMessage("cnic"));
		
		else if(bx2==false)
			ae.add(email_address, new ActionMessage("email"));
		
		else if(bx3==false)
			ae.add(m_number, new ActionMessage("mobile_number"));
		
		else if(pass.equals("") || pass.equals(null) || pass.equals(" "))
			ae.add(pass, new ActionMessage("pass"));
		
		
		return ae;
	}
	
	
	
	
	
	
}
