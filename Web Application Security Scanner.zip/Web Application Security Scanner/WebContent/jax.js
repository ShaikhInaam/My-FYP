$(document).ready(function() {
	$('#text_scanner').blur(function() {
		$.ajax({
			type : 'post',
			url : 'CheckURLServlet',
			data : {
				userName : $('#text_scanner').val()
			},
			success : function(responseText) {
				$('#ajaxGetUserServletResponse').text(responseText);
			}
		});
	});
	
	
	
	
});